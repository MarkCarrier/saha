
## Todo 

[x] Add meta
[x] Map to couch/domain object
[x] Add nice visual to popup
[x] Create phone number couch index
[x] Add index check
[x] Remove duplicate numbers
[x] Add Saving to couch
[ ] Add simple list view
[ ] Assignments
[x] Create source id index 
[ ] Block saving if already exists
[ ] Allow updating if already exists